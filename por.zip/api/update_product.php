<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'error'=>'Método não permitido']);
    exit;
}

try {
    $id    = (int) ($_POST['id'] ?? 0);
    $qtde  = (int) ($_POST['quantidade'] ?? 0);
    $preco = number_format((float)($_POST['preco'] ?? 0), 2, '.', '');
    $pub   = isset($_POST['publicado']) ? 1 : 0;

    $sql = "UPDATE produtos
            SET quantidade = :qtde,
                preco_unitario = :preco,
                publicado = :pub
            WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':qtde'  => $qtde,
        ':preco' => $preco,
        ':pub'   => $pub,
        ':id'    => $id
    ]);

    echo json_encode(['success'=>true]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>'Falha ao atualizar produto']);
}
