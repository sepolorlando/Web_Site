<?php
// /api/create_order.php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/db.php'; // define $conn (PDO)

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['success'=>false,'error'=>'Método não permitido']));
}

// 1) coleta e valida os campos
$nome     = trim($_POST['nome_cliente']     ?? '');
$data     = trim($_POST['data_nascimento']  ?? '');
$morada   = trim($_POST['morada']           ?? '');
$carrinho = json_decode($_POST['carrinho']  ?? '[]', true);

if (
    $nome === '' ||
    $data === '' ||
    $morada === '' ||
    !is_array($carrinho) ||
    empty($carrinho)
) {
    http_response_code(400);
    exit(json_encode([
      'success'=>false,
      'error'  =>'Os campos nome, data de nascimento, morada e carrinho são obrigatórios'
    ]));
}

try {
    // 2) inicia transação
    $conn->beginTransaction();

    // 3) calcula o total
    $total = 0.0;
    $stmtPreco = $conn->prepare("SELECT preco FROM produtos WHERE id = :produto_id");
    foreach ($carrinho as $item) {
        $pid = (int)($item['produto_id'] ?? 0);
        $qtd = (int)($item['quantidade']  ?? 0);
        if ($pid <= 0 || $qtd <= 0) continue;

        $stmtPreco->execute([':produto_id' => $pid]);
        if ($row = $stmtPreco->fetch(PDO::FETCH_ASSOC)) {
            $precoNum = floatval(str_replace(',', '.', $row['preco']));
            $total   += $precoNum * $qtd;
        }
    }

    // 4) insere na tabela encomendas (sem idade)
    $sqlOrder = "
      INSERT INTO encomendas
        (nome_cliente, data_nascimento, morada, preco_total, data_encomenda)
      VALUES
        (:nome_cliente, :data_nascimento, :morada, :preco_total, NOW())
    ";
    $stmtOrder = $conn->prepare($sqlOrder);
    $stmtOrder->bindValue(':nome_cliente',   $nome);
    $stmtOrder->bindValue(':data_nascimento',$data);
    $stmtOrder->bindValue(':morada',         $morada);
    $stmtOrder->bindValue(':preco_total',    number_format($total,2,'.',''));
    $stmtOrder->execute();
    $orderId = $conn->lastInsertId();

    // 5) insere os itens em encomenda_produto
    $sqlItem = "
      INSERT INTO encomenda_produtos
        (encomenda_id, produto_id, quantidade)
      VALUES (:encomenda_id, :produto_id, :quantidade)
    ";
  
    $stmtItem = $conn->prepare($sqlItem);
    foreach ($carrinho as $item) {
        $pid = (int)($item['produto_id'] ?? 0);
        $qtd = (int)($item['quantidade']  ?? 0);
        if ($pid > 0 && $qtd > 0) {
            $stmtItem->execute([
              ':encomenda_id'=> $orderId,
              ':produto_id'  => $pid,
              ':quantidade'  => $qtd
            ]);
        }
    }

    // 6) confirma tudo
    $conn->commit();
    echo json_encode(['success'=>true,'encomenda_id'=>$orderId]);
    exit;

} catch (Exception $e) {
    // em caso de erro, desfaz a transação e loga
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    error_log('create_order ERROR: '.$e->getMessage());
    http_response_code(500);
    echo json_encode([
      'success'=>false,
      'error'  =>'Erro interno ao criar encomenda: '.$e->getMessage()
    ]);
    exit;
}
