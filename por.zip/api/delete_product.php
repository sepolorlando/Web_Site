<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido']);
    exit;
}

$id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}

try {
    // inicia transação
    $conn->beginTransaction();

    // 1) busca os caminhos de todas as imagens para remover do disco
    $stmtImg = $conn->prepare("
        SELECT caminho_imagem
          FROM imagens_produtos
         WHERE produto_id = :id
    ");
    $stmtImg->execute([':id' => $id]);
    $imagens = $stmtImg->fetchAll(PDO::FETCH_COLUMN);

    // 2) exclui do banco os registros de imagens e categorias
    $conn->prepare("DELETE FROM imagens_produtos WHERE produto_id = :id")
         ->execute([':id' => $id]);

    $conn->prepare("DELETE FROM produto_categorias WHERE produto_id = :id")
         ->execute([':id' => $id]);

    // 3) exclui o próprio produto
    $conn->prepare("DELETE FROM produtos WHERE id = :id")
         ->execute([':id' => $id]);

    // 4) remove arquivos físicos das imagens (se existirem)
    foreach ($imagens as $caminho) {
        $fullPath = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR)
                  . DIRECTORY_SEPARATOR . trim($caminho, '/');
        if (is_file($fullPath)) {
            @unlink($fullPath);
        }
    }

    // confirma transação
    $conn->commit();

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    // desfaz transação em caso de erro
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    http_response_code(500);
    error_log("Erro delete_product: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Falha ao excluir o produto']);
}
