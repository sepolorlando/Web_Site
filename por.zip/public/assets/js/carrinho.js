document.addEventListener('DOMContentLoaded', () => {
  renderizarCarrinho();

  function renderizarCarrinho() {
    const lista = document.querySelector('.cart-list');
    const subtotalEl = document.querySelector('.subtotal');
    const totalEl = document.querySelector('.total');
    const carrinho = JSON.parse(localStorage.getItem('carrinho')) || {};

    if (!Object.keys(carrinho).length) {
      lista.innerHTML = '<p>Carrinho vazio.</p>';
      subtotalEl.textContent = '0,00 $';
      totalEl.textContent = '0,00 $';
      return;
    }

    fetch('/api/get_products.php')
      .then(res => res.json())
      .then(produtos => {
        lista.innerHTML = '';
        let subtotal = 0;

        Object.keys(carrinho).forEach(id => {
          const produto = produtos.find(p => p.id == id);
          const quantidade = carrinho[id];
          const preco = parseFloat(produto.preco.replace('.', '').replace(',', '.'));
          const totalProduto = preco * quantidade;
          subtotal += totalProduto;

          const li = document.createElement('li');
          li.classList.add('cart-item');
          li.innerHTML = `
            <img src="${produto.imagem}" alt="${produto.nome}">
            <div class="info">
              <strong>${produto.nome}</strong>
              <p>${produto.descricao ?? ''}</p>
              <a href="#" class="remover" data-id="${produto.id}">Remover</a>
            </div>
            <div class="quantidade">
              <button class="menos" data-id="${produto.id}">-</button>
              <span>${quantidade}</span>
              <button class="mais" data-id="${produto.id}">+</button>
            </div>
            <div class="preco">${totalProduto.toFixed(2).replace('.', ',')} $</div>
          `;
          lista.appendChild(li);
        });

        subtotalEl.textContent = subtotal.toFixed(2).replace('.', ',') + ' $';
        totalEl.textContent = subtotalEl.textContent;

        ativarBotoes();
      });
  }

  function ativarBotoes() {
    document.querySelectorAll('.mais').forEach(btn => {
      btn.addEventListener('click', () => atualizarQtd(btn.dataset.id, 1));
    });

    document.querySelectorAll('.menos').forEach(btn => {
      btn.addEventListener('click', () => atualizarQtd(btn.dataset.id, -1));
    });

    document.querySelectorAll('.remover').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        atualizarQtd(link.dataset.id, 0);
      });
    });
  }

  function atualizarQtd(id, delta) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho')) || {};
    if (delta === 0) {
      delete carrinho[id];
    } else {
      carrinho[id] = (carrinho[id] || 0) + delta;
      if (carrinho[id] <= 0) delete carrinho[id];
    }
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    renderizarCarrinho();
  }
});
//.......................................................................................................................
document.addEventListener('DOMContentLoaded', () => {
  const btnOpen = document.getElementById('btnOpenCheckout');
  const modal   = document.getElementById('checkoutModal');
  const btnClose= modal.querySelector('.modal-close');
  const form    = document.getElementById('checkoutModalForm');
  const carrField = document.getElementById('modalCarrinhoField');

  // Pega carrinho do localStorage
  function getCarrinho() {
    return JSON.parse(localStorage.getItem('carrinho') || '{}');
  }

  // Atualiza o hidden field do carrinho no modal
  function atualizarCarrinhoField() {
    carrField.value = JSON.stringify(getCarrinho());
  }

  // Abre o modal
  btnOpen.addEventListener('click', () => {
    if (!Object.keys(getCarrinho()).length) {
      return alert('Seu carrinho está vazio!');
    }
    atualizarCarrinhoField();
    modal.style.display = 'flex';
  });

  // Fecha o modal
  btnClose.addEventListener('click', () => modal.style.display = 'none');
  modal.addEventListener('click', e => {
    if (e.target === modal) modal.style.display = 'none';
  });

  // Submissão do formulário dentro do modal
  form.addEventListener('submit', async e => {
    e.preventDefault();
    atualizarCarrinhoField();
    const data = new FormData(form);

    try {
      const res  = await fetch('/api/finalizar_encomenda.php', {
        method: 'POST',
        body: data
      });
      const json = await res.json();
      if (!json.success) {
        throw new Error(json.error || 'Falha no servidor');
      }
      // sucesso: limpar carrinho, fechar modal, mostrar confirmação
      localStorage.removeItem('carrinho');
      modal.style.display = 'none';
       renderizarCarrinho();
      alert('Encomenda #' + json.encomenda_id + ' criada!');
      // opcional: redirecionar para página de sucesso
      // window.location.href = '/order_success.php?id=' + json.encomenda_id;
    } catch (err) {
      alert('Erro ao criar encomenda: ' + err.message);
      console.error(err);
    }
  });
});
