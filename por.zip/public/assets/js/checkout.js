document.getElementById('data_nascimento').addEventListener('change', function () {
  const nascimento = new Date(this.value);
  const hoje = new Date();
  let idade = hoje.getFullYear() - nascimento.getFullYear();
  const m = hoje.getMonth() - nascimento.getMonth();
  if (m < 0 || (m === 0 && hoje.getDate() < nascimento.getDate())) {
    idade--;
  }
  document.getElementById('idade').value = idade;
});

document.getElementById('checkout-form').addEventListener('submit', function(e) {
  e.preventDefault();

  const idade = parseInt(document.getElementById('idade').value);
  if (isNaN(idade) || idade < 18) {
    alert('É necessário ter pelo menos 18 anos.');
    return;
  }

  const carrinho = JSON.parse(localStorage.getItem('carrinho')) || {};
  console.logo(carrinho);
  if (Object.keys(carrinho).length === 0) {
    alert('Carrinho vazio.');
    return;
  }

  const formData = new FormData(this);
  formData.append('carrinho', JSON.stringify(carrinho)); // envia carrinho no form

  fetch(this.action, {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      localStorage.removeItem('carrinho');
      document.getElementById('mensagem-sucesso').textContent = '✅ Encomenda realizada com sucesso!';
      document.getElementById('mensagem-sucesso').style.display = 'block';
      this.reset();
      document.getElementById('idade').value = '';
    } else {
      alert(data.message || 'Erro ao finalizar encomenda.');
    }
  });
});