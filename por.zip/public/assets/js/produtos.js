// /public/assets/js/produtos.js
document.addEventListener('DOMContentLoaded', () => {
    const apiBase = '/api';
    const body = document.getElementById('productBody');
    const btnNovo = document.getElementById('btnNovo');
    const modal = document.getElementById('modalAdd');
    const closes = modal.querySelectorAll('.close');
    const imgInput = document.getElementById('img-input-modal');
    const preview = document.getElementById('img-preview-modal');
    let allProds = [];

    async function load() {
        const res = await fetch(`${apiBase}/get_all_product.php`);
        const json = await res.json();
        if (!json.success) return;
        allProds = json.data;
        render(allProds);

        // DataTable
        if ($.fn.dataTable.isDataTable('#productTable')) {
            $('#productTable').DataTable().destroy();
        }
        $('#productTable').DataTable({
            paging: true,
            pageLength: 10,
            lengthChange: false,
            searching: false,
            info: false,
            columnDefs: [
                { orderable: false, targets: [0, 4] }
            ]
        });
    }

    function render(list) {
        body.innerHTML = '';
        list.forEach(p => {

            const product_image = p.thumb ? `${window.location.origin}/public/${p.thumb}` : '/public/uploads/default-avatar.png';
            const q = String(p.quantidade).padStart(2, '0');
            const badge = p.publicado
                ? `<span class="badge bg-success">Ativo</span>`
                : `<span class="badge bg-secondary">Inativo</span>`;

            const tr = document.createElement('tr');
            tr.innerHTML = `
        <td>
          <div class="d-flex align-items-left">
            <img src="${product_image}" class="rounded-circle me-2" style="width:40px;height:40px"> </div>
        </td>
         <td class="text-left">${p.nome}</td>
        <td class="text-center">${q}</td>
        <td class="text-center">${badge}</td>
        <td class="text-end text-primary">
          ${parseFloat(p.preco_unitario).toFixed(2)}
        </td>
        <td class="text-center">
          <button class="btn btn-sm btn-primary me-1 btn-edit" data-id="${p.id}">
            <i class="bi bi-pencil"></i>
          </button>
          <button class="btn btn-sm btn-danger btn-delete" data-id="${p.id}">
            <i class="bi bi-trash"></i>
          </button>
        </td>
      `;
            body.appendChild(tr);
        });
    }

    // filtro
    document.getElementById('btnFilter').addEventListener('click', () => {
        const name = document.getElementById('filterName').value.toLowerCase();
        const status = document.getElementById('filterStatus').value;
        const filtered = allProds.filter(p =>
            p.nome.toLowerCase().includes(name) &&
            (!status || String(p.publicado) === status)
        );
        render(filtered);
    });

    // abrir modal novo
    btnNovo.addEventListener('click', () => modal.style.display = 'block');
    closes.forEach(b => b.addEventListener('click', () => modal.style.display = 'none'));
    window.addEventListener('click', e => { if (e.target === modal) modal.style.display = 'none'; });

    // preview imagens
    imgInput.addEventListener('change', function () {
        preview.innerHTML = '';
        Array.from(this.files).forEach(f => {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(f);
            img.className = 'me-1';
            img.style = 'width:50px;height:50px';
            preview.appendChild(img);
        });
    });

    // submit novo produto
    document.getElementById('form-add').addEventListener('submit', async e => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const res = await fetch(`${apiBase}/create_product.php`, {
            method: 'POST', body: fd
        });
        const json = await res.json();
        modal.style.display = 'none';
        if (json.success) {
            showSuccessPopup('Sucesso!', 'Produto adicionado com sucesso.');
            e.target.reset();
            preview.innerHTML = '';
        } else {
            showSuccessPopup('Erro', json.error || 'Falha ao adicionar.');
        }
        await load();
    });

    // editar/excluir
    body.addEventListener('click', async e => {
        const edit = e.target.closest('.btn-edit');
        const del = e.target.closest('.btn-delete');
        if (edit) {
            const id = edit.dataset.id;
            // aqui você pode abrir o modal e preencher os campos para edição
            return;
        }
        if (del) {
            const id = del.dataset.id;
            if (!confirm('Confirma exclusão?')) return;
            await fetch(`${apiBase}/delete_product.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `id=${id}`
            });
            const json = await res.json();

            // se deu erro, aborta aqui
            if (!json.success) {
                alert('Falha ao excluir: ' + (json.error || 'Erro desconhecido'));
                return;
            }else{
                showSuccessPopup('Sucesso!', 'Operação realizada.');
            }

            // só executa se deu success=true
            // 1) recarrega a lista
            await load();
        }
    });

    // popup
    function showSuccessPopup(t, m) {
        const p = document.getElementById('successPopup');
        p.querySelector('h2').textContent = t;
        p.querySelector('p').textContent = m;
        p.style.display = 'block';
    }
    document.getElementById('successOk').addEventListener('click', () => {
        document.getElementById('successPopup').style.display = 'none';
    });

    load();
});
