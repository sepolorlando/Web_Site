<?php
session_start();
if (!isset($_SESSION['account_loggedin'])) {
  header('Location: login.php');
  exit;
}
?>
<?php include '../includes/_barra_lateral.php'; ?>
<?php include '../includes/header_backofice.php'; ?>

<!-- DataTables CSS (Bootstrap 5) -->
<link
  href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css"
  rel="stylesheet"
/>
<!-- Bootstrap Icons -->
<link
  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
  rel="stylesheet"
/>

<main class="main-content">
  <section class="slider">

    <!-- Barra de filtro e botão Novo -->
    <div class="filter-bar mb-3 d-flex gap-2">
      <input type="text" id="filterName" class="form-control w-auto" placeholder="Filtrar por Nome">
      <select id="filterStatus" class="form-select w-auto">
        <option value="">Todos</option>
        <option value="1">Publicado</option>
        <option value="0">Não publicado</option>
      </select>
      <button id="btnFilter" class="btn btn-primary">Pesquisar</button>
      <button id="btnNovo" class="btn btn-success">Novo</button>
    </div>

    <!-- Tabela de produtos -->
    <div class="table-container">
      <table id="productTable" class="table table-striped table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th></th>
            <th>Produto</th>
            <th class="text-center">Qtd</th>
            <th class="text-center">Publicado</th>
            <th class="text-end">Preço</th>
            <th class="text-center">Ações</th>
          </tr>
        </thead>
        <tbody id="productBody">
          <!-- preenchido dinamicamente por produtos.js -->
        </tbody>
      </table>
    </div>

    <!-- Modal de Novo Produto -->
    <div id="modalAdd" class="modal">
      <div class="modal-content">
        <button class="close">&times;</button>
        <h2>Adicionar Produto</h2>
        <form id="form-add"
              method="post"
              action="/api/create_product.php"
              enctype="multipart/form-data">
          <div class="field"><label>Nome:</label>
            <input type="text" name="nome" class="form-control" required>
          </div>
          <div class="field"><label>Imagens:</label>
            <input type="file"
                   name="imagens[]"
                   id="img-input-modal"
                   class="form-control"
                   accept="image/*"
                   multiple>
            <div id="img-preview-modal" class="img-preview-container mt-2"></div>
          </div>
          <div class="field"><label>Categorias:</label>
            <select name="categorias[]" class="form-select" multiple required>
              <?php foreach ($categorias as $c): ?>
                <option value="<?= $c['id'] ?>">
                  <?= htmlspecialchars($c['nome']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field"><label>Quantidade:</label>
            <input type="number"
                   name="quantidade"
                   class="form-control text-center"
                   min="0"
                   value="0"
                   required>
          </div>
          <div class="field"><label>Preço:</label>
            <input type="number"
                   name="preco"
                   class="form-control text-end"
                   step="0.01"
                   min="0"
                   value="0.00"
                   required>
          </div>
          <div class="field form-check">
            <input type="checkbox"
                   name="publicado"
                   class="form-check-input"
                   id="chkPublicado">
            <label for="chkPublicado" class="form-check-label">
              Publicar?
            </label>
          </div>
          <div class="modal-actions mt-3">
            <button type="button"
                    class="btn btn-outline-secondary close">
              Cancelar
            </button>
            <button type="submit" class="btn btn-primary">
              Salvar
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Success Popup -->
    <div class="success-popup" id="successPopup">
      <div class="check-icon">✔</div>
      <h2>Sucesso!</h2>
      <p>Produto adicionado com sucesso.</p>
      <button id="successOk" class="btn btn-success">OK</button>
    </div>

  </section>
</main>

<!-- jQuery e DataTables JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script
  src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js">
</script>
<script
  src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js">
</script>

<!-- Seu script de produtos -->
<script src="/public/assets/js/produtos.js"></script>
<?php include '../includes/footer.php'; ?>
