<?php require_once __DIR__ . '/includes/header.php'; ?>



<div class="checkout-container">
    <h2>Finalizar Encomenda</h2>

    <form id="checkout-form" method="POST" action="/api/finalizar_encomenda.php">
        <div class="form-group"><label for="nome">Nome completo:</label><input type="text" name="nome" id="nome" required></div>

        <div class="form-group half"><label for="data_nascimento">Data de nascimento:</label><input type="date" name="data_nascimento" id="data_nascimento" required></div>

        <div class="form-group half"><label for="idade">Idade:</label><input type="number" name="idade" id="idade" readonly></div>

        <div class="form-group"><label for="morada">Morada:</label><input type="text" name="morada" id="morada" required></div>
          <input type="hidden" name="carrinho" id="carrinhoField" value="">

         <p><strong>Total:</strong> <strong class="total">0,00 $</strong></p>
        <button type="submit">Concluir encomenda</button>
        <div id="mensagem-sucesso" style="display:none; color: green; margin-top: 15px;"></div>
    </form>


    <script>
        document.getElementById('data_nascimento').addEventListener('change', function() {
            const nascimento = new Date(this.value);
            const hoje = new Date();
            let idade = hoje.getFullYear() - nascimento.getFullYear();
            const m = hoje.getMonth() - nascimento.getMonth();
            if (m < 0 || (m === 0 && hoje.getDate() < nascimento.getDate())) {
                idade--;
            }
            document.getElementById('idade').value = idade;
        });

        document.getElementById('checkout-form').addEventListener('submit', function(e) {
            e.preventDefault();

            const idade = parseInt(document.getElementById('idade').value);
            if (isNaN(idade) || idade < 18) {
                alert('É necessário ter pelo menos 18 anos.');
                return;
            }

            const formData = new FormData(this);

            fetch(this.action, {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        localStorage.removeItem('carrinho');
                        document.getElementById('mensagem-sucesso').textContent = '✅ Encomenda realizada com sucesso!';
                        document.getElementById('mensagem-sucesso').style.display = 'block';
                        this.reset();
                        document.getElementById('idade').value = '';
                    } else {
                        alert(data.message || 'Erro ao finalizar encomenda.');
                    }
                });
        });
    </script>

    <?php require_once __DIR__ . '/includes/footer.php'; ?>