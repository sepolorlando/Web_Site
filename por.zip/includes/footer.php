<footer class="inwood-footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Aleida Tavares. All rights reserved.</p>
    </div>
</footer>



</body>
</html>