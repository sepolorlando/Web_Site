<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gestao de loja</title>
    <link rel="stylesheet" href="/public/assets/css/home.css">
    <link rel="stylesheet" href="/public/assets/css/produtos.css">
    <link rel="stylesheet" href="/public/assets/css/popup.css">
    <link
  href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css"
  rel="stylesheet"
/>
</head>

<body>

<header class="topbar">
  <div class="brand">
    <i class="fas fa-graduation-cap"></i>
    <span>PORTAL</span>
  </div>
  <button class="toggle-btn"><i class="fas fa-bars"></i></button>
  <nav class="top-nav">
    <a href="/backofice/home.php">HOME</a>
    <a href="/backofice/perfil.php">PERFIL</a>
   <a href="logout.php">
                <svg width="12" height="12" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                    <path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z" />
                </svg>
                Logout
            </a>
  </nav>
</header>
